// Square.h

#include "Rectangle.h"

#ifndef Square_h
#define Square_h

class Square: public Rectangle {
public:
	Square(int); // constructor
	void setSideA(int);
	void setSideB(int);
};





#endif